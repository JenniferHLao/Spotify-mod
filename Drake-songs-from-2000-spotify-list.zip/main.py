#spotify application
#jennifer lao
#march 26th

#create a list
#open the data filter
file = open("spotify.csv")
#get rid of the first line
file.readline()

drake_songs = []

for line in file:
  data = line.strip().split(",")
  artist = data[-1]
  song = data[-2]
  dancibility = data[3]
  
  if artist.lower() == "drake":
    record = (artist, song, dancibility)
    drake_songs.append(record)


for datum in drake_songs:
  print(datum[2] +"\t" +datum[0] + "\t" + datum[1])

#sort the data into drake_songs list using selection sort







